//
//  MyBookingsViewController.swift
//  BookMyCourt
//
//  Created by Vallamsetty,Revanth on 2/16/18.
//  Copyright © 2018 Student. All rights reserved.
//

import UIKit
import Parse
class MyBookingsViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    var bookings:[String] = ["Date 03/15/2018 14:30 Right court","Date 04/12/2018 13:30 Left court","Date 05/15/2018 9:30 Centre court"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title="View Bookings"
        AppDelegate.dfetch.loadUserData()
        // Do any additional setup after loading the view.
    }
    @IBOutlet weak var Txt919TF: UITextField!
    @IBOutlet weak var TxtPNTF: UITextField!
    @IBOutlet weak var userBookingsTV: UITableView!
    override func viewWillAppear(_ animated: Bool) {
        if(AppDelegate.userPN != "" && AppDelegate.userPN.count == 10 && String(AppDelegate.user919).count == 9){
            TxtPNTF.text=AppDelegate.userPN
            Txt919TF.text=String(AppDelegate.user919)
        }else{
            TxtPNTF.text=""
            Txt919TF.text=""
        }
        AppDelegate.dfetch.loadUserData()
            self.userBookingsTV.reloadData()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return AppDelegate.dfetch.getUserData().count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Booking")
        print(AppDelegate.dfetch.getUserData()[indexPath.row].Bookings)
        cell?.textLabel?.text = String(AppDelegate.dfetch.getUserData()[indexPath.row].Bookings.split(separator: " ")[0])
        cell?.detailTextLabel?.text = String(AppDelegate.dfetch.getUserData()[indexPath.row].Bookings.split(separator: " ")[1])
        return cell!
    }
    
    @IBAction func ViewBookingsBTNAction(_ sender: Any) {
        if(Txt919TF.text!.count>0&&TxtPNTF.text!.count>0){
            let T919Num = Txt919TF.text!
            let TxtPN = TxtPNTF.text!
            if(T919Num.prefix(3) != "919" || T919Num.count != 9){
                self.displayOKAlert(title: "Error!", message:"Invalid 919 Number")
            }
            else if(TxtPN.count != 10){
                self.displayOKAlert(title: "Error!", message:"Invalid Phone Number")
            }
            else{
                AppDelegate.user919 = Int(Txt919TF.text!)!
                AppDelegate.userPN = TxtPNTF.text!
                AppDelegate.dfetch.loadUserData()
                print("Passed user data into view controller \(AppDelegate.dfetch.getUserData().count)")
                self.userBookingsTV.reloadData()
            }
        }else{
            self.displayOKAlert(title: "Error!", message:"Please enter all the fields to view reservations!")
        }

    }
    func displayOKAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
