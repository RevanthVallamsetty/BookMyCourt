//
//  DataFetch.swift
//  BookMyCourt
//
//  Created by Vallamsetty,Revanth on 4/16/18.
//  Copyright © 2018 Student. All rights reserved.
//

import Foundation
import Parse
class DataFetch{
//    private static var SharedDFModel:DataFetch{
//        let dfmodel=DataFetch()
//        return dfmodel
//    }
    var users:[Users]
    var availabilities:[Availability]
    var temp:[Availability]=[]
    init() {
        users=[]
        availabilities=[]
    }
    func loadAvailabilityData(SelectedDate date:String){
        self.temp=[]
                let query = PFQuery(className:"Availability")
                 query.whereKey("Date", equalTo:date)
                query.findObjectsInBackground {
                    (objects: [PFObject]?, error: Error?) -> Void in
                    if error == nil
                    {
                        self.availabilities=[]
                        for i in 0..<objects!.count{
                            if(objects![i]["IsAvailable"] as! Bool){
                                self.availabilities.append(Availability(Availability_Key:objects![i].objectId!,Availability_ID: objects![i]["Availability_ID"] as! Int, Timeslot: objects![i]["Timeslot"] as! String,IsAvailable: objects![i]["IsAvailable"] as! Bool,courtLocation: objects![i]["Court"] as! String))
                            }
                        }
//                        print(self.availabilities.count)
                    }
                    else {
                        // Log details of the failure
                        print("Oops \(error!)")
        
                    }
        
                }

        }
    func loadUserData(){
        let query = PFQuery(className:"Users")
         query.whereKey("User_ID", equalTo:AppDelegate.user919)
        query.whereKey("PhoneNumber", equalTo:AppDelegate.userPN)
        query.findObjectsInBackground {
            (objects: [PFObject]?, error: Error?) -> Void in
            if error == nil
            {
                self.users=[]
                for i in 0..<objects!.count{
                        self.users.append(Users(User_ID: objects![i]["User_ID"] as! Int, PhoneNumber: objects![i]["PhoneNumber"] as! String,Bookings: objects![i]["Bookings"] as! String))

                }
                                        print("User fetched \(self.users.count)")
            }
            else {
                // Log details of the failure
                print("Oops \(error!)")
                
            }
            
        }
        
    }
    func getUserData() -> [Users] {
        return users
    }
    func getAvailabilities() -> [Availability] {
        return availabilities
    }
//    class func sharedDF() -> DataFetch {
//        return SharedDFModel
//    }
}

