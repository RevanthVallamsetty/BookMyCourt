//
//  UserModel.swift
//  BookMyCourt
//
//  Created by student on 3/9/18.
//  Copyright © 2018 Student. All rights reserved.
//

import Foundation

class Users {
    var User_ID:Int
    var PhoneNumber:String
    var Bookings:String
    
    init(User_ID:Int,PhoneNumber:String,Bookings:String) {
        self.User_ID = User_ID
        self.PhoneNumber = PhoneNumber
        self.Bookings = Bookings
    }
}

