//
//  AvailabilityModel.swift
//  BookMyCourt
//
//  Created by student on 3/9/18.
//  Copyright © 2018 Student. All rights reserved.
//

import Foundation

class  Availability{
    var Availability_Key:String
    var Availability_ID:Int
    var Timeslot:String
    var IsAvailable:Bool
    var courtLocation:String
    init() {
        Availability_Key=""
        self.Availability_ID = 0
        self.Timeslot = ""
        self.IsAvailable = false
        self.courtLocation=""
    }
    init(Availability_Key:String,Availability_ID:Int,Timeslot:String,IsAvailable:Bool,courtLocation:String) {
        self.Availability_Key = Availability_Key
        self.Availability_ID = Availability_ID
        self.Timeslot = Timeslot
        self.IsAvailable = IsAvailable
        self.courtLocation=courtLocation
    }
}

